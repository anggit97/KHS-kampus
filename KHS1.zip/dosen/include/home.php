
          <h1>
            Home
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
          </ol>

<hr>

<h5><b><?php echo date("l, M Y"); ?></b></h5>
<center><h2>Selamat Datang <b><?php echo $data['nama_dosen']; ?></b></h2></center>
