<?php  
session_start();
unset($_SESSION['role']);
echo "<META HTTP-EQUIV='Refresh' Content='0; URL=../KHS/'>";
?>