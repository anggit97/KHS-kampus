              <!-- quick email widget -->
              <div class="box box-info">
                <div class="box-header">
                  <i class="fa fa-pencil"></i>
                  <h3 class="box-title">Edit Data Pribadi</h3>
                  
                </div>
                <div class="box-body">
                  <form action="#" method="post">
                    <div class="form-group">
                      <label for="sel1">Email *</label>
                      <input type="email" class="form-control" name="emailto" placeholder="Email to:">
                    </div>
                    <div class="form-group">
                      <label for="sel1">Nama *</label>
                      <input type="text" class="form-control" name="subject" placeholder="Subject">
                    </div>
                    <div class="form-group">
                      <label for="sel1">Golongan</label>
                      <input type="text" class="form-control" name="subject" placeholder="Golongan">
                    </div>
                    <div class="form-group">
                      <label for="sel1">Kelamin</label>
                      <select class="form-control" id="sel1">
                        <option>Pria</option>
                        <option>Wanita</option>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="sel1">No. Telp/HP</label>
                      <input type="tel" class="form-control" name="subject" placeholder="Subject">
                    </div>
                    <div class="form-group">
                      <label for="sel1">Status Kawin</label>
                      <select class="form-control" id="sel1">
                        <option>Belum Kawin</option>
                        <option>Kawin</option>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="sel1">Pendidikan</label>
                      <select class="form-control" id="sel1">
                        <option>SD</option>
                        <option>SMP</option>
                        <option>SMA</option>
                        <option>S1</option>
                        <option>S2</option>
                        <option>S3</option>
                      </select>
                    </div>
                    <div>
                      <label for="">Alamat Tinggal *</label>
                      <textarea class="textarea" placeholder="Alamat" style="width: 100%; height: 125px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
                    </div>
                    <div>
                      <label for="">Alamat Asal</label>
                      <textarea class="textarea" placeholder="Alamat" style="width: 100%; height: 125px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
                    </div>
                    <div class="form-group">
                      <label for="sel1">Tanggal Masuk</label>
                      <input type="text" class="form-control" name="subject" placeholder="Tanggal Masuk">
                    </div>
                    <div class="form-group">
                      <label for="sel1">Organisasi *</label>
                      <input type="tel" class="form-control" name="subject" placeholder="Organisasi">
                    </div>
                  </form>
                </div>
                <div class="box-footer clearfix">
                  <button class="pull-right btn btn-primary" id="sendEmail">Edit <i class="fa fa-arrow-circle-right"></i></button>
                </div>
              </div>

              <div class="box box-info">
                
              </div>